const url = window.location.href.toLowerCase();

const prohibidas = ["avion", "11/9", "bomba", "explosivo", "drogas"];

if (prohibidas.some(palabra => url.includes(palabra))) {
    window.location.href = chrome.runtime.getURL("pagina.html");
}

import java.util.Scanner;

public class Bingo {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Controller controller = new Controller();
        int opcion = 0;
        System.out.println("---BIENVENIDO AL JUEGO DEL BINGO---");
        System.out.println("Los espacios en los que el numero valga 0 significa que el numero en esa casilla fue cantado");
        System.out.println("En el momento que todas las casillas sean 0 el carton estara completo y ganarás!");
        System.out.println("Aviso: Al rellenar el carton el numero 0 en el centro equivale al espacio libre.");
        System.out.println("Mucha suerte y a jugar!");
        System.out.println();
        do {

            System.out.println("Menu Bingo");
            System.out.println("1. Rellenar carton");
            System.out.println("2. Sacar numero");
            System.out.println("3. Mostrar carton");
            System.out.println("4. Salir");
            opcion = scanner.nextInt();
            switch (opcion) {
                case 1 -> {
                    controller.rellenarCarton();
                }
                case 2 -> {
                    controller.sacarNumero();
                }
                case 3 -> {
                    controller.mostrarCarton();
                }
                case 4 -> {
                    System.out.println("Saliendo del programa...");
                }
                default -> {
                    System.out.println("Opcion no comprendida");
                }
            }
            if (controller.aciertos == 25) {
                System.out.println("Bingo! Has ganado el juego!");
                controller.mostrarCarton();
                System.out.println("Saliendo del programa...");
                break;
            }
        } while (opcion != 4);
    }
}

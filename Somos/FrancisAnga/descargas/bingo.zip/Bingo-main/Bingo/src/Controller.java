import java.lang.reflect.Array;

public class Controller {
    private int[][] carton1;
    private boolean esta = false;
    private int numeros;
    private int numeroBingo;
    private boolean lineaCantada;
    private int[] numerosCantados;
    private int totalCantados;
    public int aciertos;

    public Controller() {
        carton1 = new int[5][5];
        numerosCantados = new int[75];
        lineaCantada = false;
        totalCantados = 0;
        aciertos = 1;
    }


    public void rellenarCarton() {
        System.out.println();
        for (int i = 0; i < carton1.length; i++) {
            for (int j = 0; j < carton1[i].length; j++) {
                do {
                    numeros = (int) (Math.random() * 75) + 1;
                    esta = false;
                    for (int k = 0; k < 5; k++) {
                        for (int l = 0; l < 5; l++) {
                            if (carton1[k][l] == numeros) {
                                esta = true;
                                break;
                            }
                        }
                    }
                } while (esta);
                carton1[i][j] = numeros;
            }
        }
        carton1[2][2] = 0;
        System.out.println("Carton rellenado correctamente");
        System.out.println();
    }

    public void mostrarCarton() {
        System.out.println();
        System.out.println("Carton Bingo");
        for (int[] item : carton1) {
            for (Object item2 : item) {
                System.out.print(item2 + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }

    public void sacarNumero() {
        boolean esta = false;
        System.out.println();
        do {
            numeroBingo = (int) (Math.random() * 75) + 1;
            esta = false;
            for (int i = 0; i < numerosCantados.length; i++) {
                if (numerosCantados[i] == numeroBingo) {
                    esta = true;
                    break;
                }
            }
        } while (esta);

        numerosCantados[totalCantados] = numeroBingo;
        totalCantados++;

        System.out.println("Numero Bingo: " + numeroBingo);
        System.out.println();

        for (int i = 0; i < carton1.length; i++) {
            for (int j = 0; j < carton1[i].length; j++) {
                if (carton1[i][j] == numeroBingo) {
                    carton1[i][j] = 0;
                    esta = true;
                    aciertos++;
                    break;
                }
            }
        }

        if (esta) {
            System.out.println("¡Número acertado!\n");
        }

        if (!lineaCantada && estaLinea()) {
            System.out.println("¡Línea!\n");
            lineaCantada = true;
        }
    }

    private boolean estaLinea() {
        boolean linea = false;
        for (int i = 0; i < 5; i++) {
            linea = true;
            for (int j = 0; j < 5; j++) {
                if (carton1[i][j] != 0) {
                    linea = false;
                    break;
                }
            }
            if (linea) {
                return true;
            }
        }
        for (int i = 0; i < 5; i++) {
            linea = true;
            for (int j = 0; j < 5; j++) {
                if (carton1[j][i] != 0) {
                    linea = false;
                }
            }
            if (linea) {
                return true;
            }
        }
        boolean lineaDiag = true;
        for (int i = 0; i < 5; i++) {
            if (carton1[i][i] != 0) {
                lineaDiag = false;
                break;
            }
        }
        if (lineaDiag) {
            return true;
        }
        boolean lineaDiag2 = true;
        for (int i = 0; i < carton1.length; i++) {
            if (carton1[i][carton1.length - 1 - i] != 0) {
                lineaDiag2 = false;
                break;
            }
        }
        if (lineaDiag2) {
            return true;
        }
        return false;
    }
}
